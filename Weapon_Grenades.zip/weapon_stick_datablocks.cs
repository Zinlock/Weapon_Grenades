datablock AudioProfile(grenade_stickBounceSound)
{
	filename    = "./wav/bounce2.wav";
	description = AudioShort3D;
	preload = true;

	pitchRange = 6;
};
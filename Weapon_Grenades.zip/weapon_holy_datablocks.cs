datablock AudioProfile(grenade_holyExplosionSound)
{
	filename    = "./wav/blast_ied.wav";
	description = AudioDefault3D;
	preload = true;

	pitchRange = 12;
};